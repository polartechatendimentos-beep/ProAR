-- Migração incremental: não remove proar_state nem altera registros existentes.
-- As tabelas abaixo passam a ser a fonte auditável dos novos fluxos operacionais.
create table if not exists public.proar_stock_movements (
  id uuid primary key default gen_random_uuid(), company_id text not null, product_id text not null,
  service_order_id text, purchase_id text, movement_type text not null check (movement_type in ('entrada','reserva','liberacao','consumo','ajuste','perda','devolucao')),
  quantity numeric(14,3) not null, unit_cost numeric(14,4), occurred_at timestamptz not null default now(),
  created_by text, note text, created_at timestamptz not null default now()
);
create index if not exists proar_stock_movements_company_product_idx on public.proar_stock_movements(company_id, product_id, occurred_at desc);

create table if not exists public.proar_nfe_documents (
  id uuid primary key default gen_random_uuid(), company_id text not null, access_key text not null,
  supplier_document text, supplier_name text, invoice_number text, issued_at timestamptz,
  xml_url text, pdf_url text, payload jsonb not null default '{}'::jsonb,
  status text not null default 'importada' check (status in ('importada','vinculada','entrada_gerada','cancelada','erro')),
  imported_by text, imported_at timestamptz not null default now(), unique(company_id, access_key)
);

create table if not exists public.proar_agenda_events (
  id uuid primary key default gen_random_uuid(), company_id text not null, service_order_id text,
  technician_id text, vehicle_id text, starts_at timestamptz not null, ends_at timestamptz not null,
  address text, city text, status text not null default 'agendado', route_minutes integer,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists proar_agenda_events_technician_time_idx on public.proar_agenda_events(company_id, technician_id, starts_at, ends_at);

create table if not exists public.proar_whatsapp_events (
  id uuid primary key default gen_random_uuid(), company_id text not null, service_order_id text,
  event_type text not null, recipient text not null, template_name text, payload jsonb not null default '{}'::jsonb,
  status text not null default 'pendente' check (status in ('pendente','enviado','falhou','cancelado')),
  scheduled_for timestamptz, sent_at timestamptz, provider_message_id text, error_message text,
  created_at timestamptz not null default now()
);
create index if not exists proar_whatsapp_events_due_idx on public.proar_whatsapp_events(company_id, status, scheduled_for);

alter table public.proar_stock_movements enable row level security;
alter table public.proar_nfe_documents enable row level security;
alter table public.proar_agenda_events enable row level security;
alter table public.proar_whatsapp_events enable row level security;
