import { NextRequest, NextResponse } from "next/server";
import { readSession } from "@/lib/proar-auth";
import { insertOperational } from "@/lib/operational-repository";

export async function POST(request: NextRequest) {
  const user=readSession(request.cookies.get("proar_session")?.value); if(!user)return NextResponse.json({error:"Sessão inválida."},{status:401});
  try { const body=await request.json(); const accessKey=String(body.accessKey||"").replace(/\D/g,"");
    if(accessKey.length!==44)return NextResponse.json({error:"Informe a chave de acesso de 44 dígitos da NF-e."},{status:400});
    const rows=await insertOperational(user,"proar_nfe_documents",{access_key:accessKey,supplier_document:String(body.supplierDocument||"").replace(/\D/g,""),supplier_name:String(body.supplierName||""),invoice_number:String(body.invoiceNumber||""),issued_at:body.issuedAt||null,xml_url:body.xmlUrl||null,pdf_url:body.pdfUrl||null,payload:{items:Array.isArray(body.items)?body.items:[],source:body.source||"manual"},status:"importada",imported_by:user.displayName||"Usuário"});
    return NextResponse.json({saved:true,nfe:rows[0],nextAction:"Vincular itens existentes, cadastrar os novos e confirmar a entrada no estoque."});
  } catch { return NextResponse.json({error:"Não foi possível registrar a NF-e. Confirme se a chave ainda não foi importada."},{status:503}); }
}
