import { resolveTenantDb, tenantHeaders } from "@/lib/tenant-rest";

type Session = { companyId?: string; displayName?: string };
const primaryCompany = () => String(process.env.PROAR_PRIMARY_COMPANY_ID || "polartech-principal").replace(/[^a-zA-Z0-9_-]/g, "") || "polartech-principal";

export async function operationalDb(session: Session) {
  const companyId = session.companyId || primaryCompany();
  const db = await resolveTenantDb(session.companyId);
  if (!db.url || !db.key) throw new Error("Banco operacional indisponível");
  return { companyId, url: db.url, headers: tenantHeaders(db.key) };
}

export async function insertOperational<T extends Record<string, unknown>>(session: Session, table: string, record: T) {
  const db = await operationalDb(session);
  const response = await fetch(`${db.url}/rest/v1/${table}`, { method: "POST", headers: { ...db.headers, Prefer: "return=representation" }, body: JSON.stringify({ ...record, company_id: db.companyId }) });
  if (!response.ok) throw new Error(await response.text());
  return (await response.json()) as T[];
}

export async function listOperational<T>(session: Session, table: string, query = "") {
  const db = await operationalDb(session);
  const separator = query ? "&" : "?";
  const response = await fetch(`${db.url}/rest/v1/${table}?company_id=eq.${encodeURIComponent(db.companyId)}${query ? `${separator}${query}` : ""}`, { headers: db.headers, cache: "no-store" });
  if (!response.ok) throw new Error(await response.text());
  return (await response.json()) as T[];
}
