import fs from "fs";
import path from "path";

const versionFilePath = path.resolve("lib/release-version.ts");

if (fs.existsSync(versionFilePath)) {
  const content = fs.readFileSync(versionFilePath, "utf8");
  const match = content.match(/APP_VERSION\s*=\s*["']V(\d+)\.(\d+)["']/);

  if (match) {
    const major = parseInt(match[1], 10);
    const minor = parseInt(match[2], 10) + 1;
    const newVersion = `V${major}.${minor}`;
    const newContent = content.replace(/APP_VERSION\s*=\s*["']V\d+\.\d+["']/, `APP_VERSION = "${newVersion}"`);
    fs.writeFileSync(versionFilePath, newContent, "utf8");
    console.log(`[Release Version] Atualizado com sucesso para: ${newVersion}`);
  } else {
    console.warn("[Release Version] Padrão de versão não encontrado.");
  }
} else {
  console.error(`[Release Version] Arquivo ${versionFilePath} não encontrado.`);
}
