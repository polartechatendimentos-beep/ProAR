"use client";

import React, { useState, useEffect, useRef } from "react";
import { 
  ShoppingCart, Search, CreditCard, Banknote, QrCode, 
  Trash2, Plus, Minus, Check, AlertCircle, RefreshCw, X,
  FileText, Pencil, Printer, Calendar, Clock, Maximize2, Keyboard, CheckCircle2, ChevronDown
} from "lucide-react";
import { StandardDocumentReport, ReportItem } from "@/components/StandardDocumentReport";

interface CartItem {
  id: string;
  codigo: string;
  descricao: string;
  tipo: "PRODUTO" | "SERVIÇO";
  quantidade: number;
  valorUnitario: number;
  valorTotal: number;
  capacidade?: string;
  isRecent?: boolean;
}

interface SaleRecord {
  id: string;
  numero: string;
  cliente: string;
  unidade: string;
  situacao: string;
  itensCount: number;
  valor: number;
  data: string;
  itens: ReportItem[];
}

export function PdvBalcaoPanel() {
  const [activeSubTab, setActiveSubTab] = useState<"nova_venda" | "historico" | "caixa">("historico");

  // ==========================================
  // ESTADOS DA NOVA VENDA (FRENTE DE CAIXA)
  // ==========================================
  const [items, setItems] = useState<CartItem[]>([
    {
      id: "1",
      codigo: "GAS-R410A",
      descricao: "Fluído Refrigerante Ecológico R410A (Carga p/ Split 12.000)",
      tipo: "PRODUTO",
      quantidade: 1,
      valorUnitario: 180.0,
      valorTotal: 180.0,
      capacidade: "Split 12.000 BTUs",
    },
    {
      id: "2",
      codigo: "SRV-HIG-PMOC",
      descricao: "Higienização Completa com Aplicação de Bactericida PMOC",
      tipo: "SERVIÇO",
      quantidade: 1,
      valorUnitario: 220.0,
      valorTotal: 220.0,
      capacidade: "Aparelho Hi-Wall",
    },
  ]);

  const [inputCode, setInputCode] = useState("");
  const [selectedItemId, setSelectedItemId] = useState<string>("1");
  const [cliente, setCliente] = useState("Consumidor final");
  const [vendedor, setVendedor] = useState("Técnico Balcão ProAR");

  // Modal de Pagamento (F4/F7)
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [valorPix, setValorPix] = useState(0);
  const [valorDinheiro, setValorDinheiro] = useState(0);
  const [valorCartao, setValorCartao] = useState(0);

  // ==========================================
  // ESTADOS DO HISTÓRICO DE VENDAS (GERENCIADOR)
  // ==========================================
  const [searchHistory, setSearchHistory] = useState("");
  const [statusFilter, setStatusFilter] = useState("Todos");
  const [salesHistory, setSalesHistory] = useState<SaleRecord[]>([
    {
      id: "1",
      numero: "VEN-662316",
      cliente: "GREENPLAC TECNOLOGIA INDUSTRIAL LTDA",
      unidade: "Matriz",
      situacao: "Pedido confirmado",
      itensCount: 5,
      valor: 1513.40,
      data: "13/08/2026",
      itens: [
        { itemNum: "01", equipamentoOuItem: "Higienização Completa e Assepsia PMOC", capacidadeOuDetalhes: "Split 30.000 BTUs", quantidade: 2, valorUnitario: 250.0, valorTotal: 500.0 },
        { itemNum: "02", equipamentoOuItem: "Higienização Completa e Assepsia PMOC", capacidadeOuDetalhes: "Split 12.000 BTUs", quantidade: 3, valorUnitario: 180.0, valorTotal: 540.0 },
        { itemNum: "03", equipamentoOuItem: "Carga de Fluído Ecológico R410A DuPont", capacidadeOuDetalhes: "Carga Completa", quantidade: 1, valorUnitario: 280.0, valorTotal: 280.0 },
        { itemNum: "04", equipamentoOuItem: "Capacitor Duplo 45uF + 5uF 440V", capacidadeOuDetalhes: "Peça de Reposição", quantidade: 1, valorUnitario: 95.0, valorTotal: 95.0 },
        { itemNum: "05", equipamentoOuItem: "Filtro de Ar de Alta Densidade", capacidadeOuDetalhes: "Kit 2 Telas", quantidade: 1, valorUnitario: 98.40, valorTotal: 98.40 },
      ],
    },
    {
      id: "2",
      numero: "VEN-938912",
      cliente: "Consumidor final",
      unidade: "Matriz",
      situacao: "Pedido confirmado",
      itensCount: 1,
      valor: 17.25,
      data: "13/08/2026",
      itens: [
        { itemNum: "01", equipamentoOuItem: "Pilhas Alcalinas AAA p/ Controle Remoto (Par)", capacidadeOuDetalhes: "Insumo Balcão", quantidade: 1, valorUnitario: 17.25, valorTotal: 17.25 },
      ],
    },
  ]);

  // Modal de Impressão de Pedido A4 Padronizado
  const [printDocumentData, setPrintDocumentData] = useState<StandardDocumentProps | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (activeSubTab === "nova_venda") {
      inputRef.current?.focus();
    }
  }, [activeSubTab]);

  // Atalhos de teclado F1-F12
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeSubTab !== "nova_venda") return;
      if (e.key === "F1") {
        e.preventDefault();
        const nome = prompt("Informe o nome ou CNPJ/CPF do Cliente:", cliente);
        if (nome) setCliente(nome);
      } else if (e.key === "F4" || e.key === "F7") {
        e.preventDefault();
        setShowPaymentModal(true);
      } else if (e.key === "F8") {
        e.preventDefault();
        handleRemoveItem(selectedItemId);
      } else if (e.key === "F9") {
        e.preventDefault();
        if (confirm("Deseja realmente cancelar toda a venda atual?")) {
          setItems([]);
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedItemId, cliente, activeSubTab]);

  const totalVenda = items.reduce((acc, i) => acc + i.valorTotal, 0);
  const totalPago = valorPix + valorDinheiro + valorCartao;
  const faltaPagar = Math.max(0, totalVenda - totalPago);
  const troco = Math.max(0, totalPago - totalVenda);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) return;

    let multiplier = 1;
    let codeOrDesc = inputCode.trim();

    const match = codeOrDesc.match(/^(\d+)[\*xX](.+)$/);
    if (match) {
      multiplier = parseInt(match[1], 10) || 1;
      codeOrDesc = match[2].trim();
    }

    const unitPrice = codeOrDesc.toLowerCase().includes("gas") ? 180 : 150;
    const newItem: CartItem = {
      id: Date.now().toString(),
      codigo: codeOrDesc.toUpperCase(),
      descricao: `Item / Serviço: ${codeOrDesc.toUpperCase()}`,
      tipo: codeOrDesc.toLowerCase().includes("srv") ? "SERVIÇO" : "PRODUTO",
      quantidade: multiplier,
      valorUnitario: unitPrice,
      valorTotal: unitPrice * multiplier,
      isRecent: true,
    };

    setItems([newItem, ...items]);
    setSelectedItemId(newItem.id);
    setInputCode("");

    setTimeout(() => {
      setItems((prev) => prev.map((i) => (i.id === newItem.id ? { ...i, isRecent: false } : i)));
    }, 1500);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newQtd = Math.max(1, item.quantidade + delta);
          return {
            ...item,
            quantidade: newQtd,
            valorTotal: newQtd * item.valorUnitario,
          };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Filtragem do Histórico
  const filteredHistory = salesHistory.filter((s) => {
    const matchText =
      s.cliente.toLowerCase().includes(searchHistory.toLowerCase()) ||
      s.numero.toLowerCase().includes(searchHistory.toLowerCase()) ||
      s.unidade.toLowerCase().includes(searchHistory.toLowerCase());
    const matchStatus = statusFilter === "Todos" || s.situacao === statusFilter;
    return matchText && matchStatus;
  });

  const totalValorFiltrado = filteredHistory.reduce((acc, s) => acc + s.valor, 0);

  // Abertura da Impressão de Pedido pelo Histórico
  const handlePrintHistoryOrder = (sale: SaleRecord) => {
    setPrintDocumentData({
      tipo: "PEDIDO",
      numero: sale.numero,
      data: sale.data,
      cliente: {
        nome: sale.cliente,
        endereco: `${sale.unidade} — Mirassol/SP`,
      },
      descricaoServico: `Fornecimento e faturamento comercial referente ao pedido ${sale.numero} com entrega técnica e garantia de fábrica.`,
      itens: sale.itens,
      valorGlobal: sale.valor,
      condicoesComerciais: {
        formaPagamento: "Faturado / PIX / Cartão",
        validade: "Concluído",
        garantia: "90 (noventa) dias de garantia técnica legal (CDC)",
        prazo: "Entrega / Retirada Imediata",
      },
      onClose: () => setPrintDocumentData(null),
    });
  };

  return (
    <div className="space-y-4">
      {/* ============================================================== */}
      {/* TABS SUPERIORES DE VENDAS (Nova venda | Histórico | Caixa)      */}
      {/* ============================================================== */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveSubTab("nova_venda")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeSubTab === "nova_venda"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Nova venda
          </button>
          <button
            onClick={() => setActiveSubTab("historico")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeSubTab === "historico"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Histórico
          </button>
          <button
            onClick={() => setActiveSubTab("caixa")}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeSubTab === "caixa"
                ? "bg-blue-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            Caixa
          </button>
        </div>

        <button
          onClick={() => setActiveSubTab("nova_venda")}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow transition"
        >
          <Plus className="w-4 h-4" /> Nova venda
        </button>
      </div>

      {/* ============================================================== */}
      {/* BANNER DE IDENTIFICAÇÃO DO PDV PROAR                            */}
      {/* ============================================================== */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400 bg-blue-900/40 border border-blue-800 px-2 py-0.5 rounded">
              VENDA RÁPIDA
            </span>
          </div>
          <h2 className="text-xl font-black text-white tracking-tight">PDV ProAR</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Produtos e serviços em um fluxo direto, sem campos desnecessários.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button className="px-3.5 py-1.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-slate-200 transition flex items-center gap-1.5">
            <Maximize2 className="w-3.5 h-3.5 text-slate-400" /> Maximizar PDV
          </button>
          <button className="px-3.5 py-1.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-slate-200 transition flex items-center gap-1.5">
            <Keyboard className="w-3.5 h-3.5 text-slate-400" /> <span className="text-[10px] font-bold px-1 rounded bg-slate-800 border border-slate-700">F1</span> Atalhos
          </button>
          <div className="px-3 py-1.5 rounded-xl border border-emerald-800/80 bg-emerald-950/40 text-xs font-bold text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            Caixa aberto
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* ABA 2: HISTÓRICO DE VENDAS (GERENCIADOR DE VENDAS) - CORRIGIDO   */}
      {/* ============================================================== */}
      {activeSubTab === "historico" && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl text-white">
          {/* Top Header & Métricas */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-blue-400 uppercase tracking-wider mb-1">
                <FileText className="w-4 h-4 text-blue-500" /> GERENCIADOR DE VENDAS
              </div>
              <h1 className="text-2xl font-black text-white tracking-tight">Controle comercial</h1>
              <p className="text-xs text-slate-400 mt-1">
                Dê dois cliques no pedido para editar os dados e itens.
              </p>
            </div>

            {/* Cards de Métricas */}
            <div className="grid grid-cols-3 gap-3 shrink-0">
              <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center min-w-[100px]">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">REGISTROS</span>
                <span className="text-xl font-black text-white mt-0.5 block font-mono">{filteredHistory.length}</span>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center min-w-[140px]">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">VALOR FILTRADO</span>
                <span className="text-xl font-black text-emerald-400 mt-0.5 block font-mono">
                  R$ {totalValorFiltrado.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl text-center min-w-[140px]">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">APROVADOS / CONCLUÍDOS</span>
                <span className="text-xl font-black text-blue-400 mt-0.5 block font-mono">{filteredHistory.length}</span>
              </div>
            </div>
          </div>

          {/* Barra de Pesquisa e Filtro de Situação */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchHistory}
                onChange={(e) => setSearchHistory(e.target.value)}
                placeholder="Pesquisar vendas por cliente, número ou unidade..."
                className="w-full bg-slate-900 text-white placeholder-slate-500 pl-10 pr-4 py-2.5 rounded-xl border border-slate-800 focus:border-blue-500 outline-none text-xs font-medium"
              />
            </div>

            <div className="w-full sm:w-48 shrink-0">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full bg-slate-900 text-white px-3 py-2.5 rounded-xl border border-slate-800 focus:border-blue-500 outline-none text-xs font-bold"
              >
                <option value="Todos">Todos</option>
                <option value="Pedido confirmado">Pedido confirmado</option>
                <option value="Pendente">Pendente</option>
                <option value="Cancelado">Cancelado</option>
              </select>
            </div>
          </div>

          {/* ============================================================== */}
          {/* TABELA DE HISTÓRICO COM CABEÇALHO E COLUNAS 100% ALINHADAS     */}
          {/* ============================================================== */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50 shadow-inner">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-950/90 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4 w-36 shrink-0">NÚMERO</th>
                    <th className="py-3.5 px-4 min-w-[280px]">CLIENTE / UNIDADE</th>
                    <th className="py-3.5 px-4 w-44">SITUAÇÃO</th>
                    <th className="py-3.5 px-4 w-20 text-center">ITENS</th>
                    <th className="py-3.5 px-4 w-36 text-right">VALOR</th>
                    <th className="py-3.5 px-4 w-32 text-center">DATA</th>
                    <th className="py-3.5 px-4 w-28 text-center">AÇÕES</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80 text-xs">
                  {filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-500">
                        Nenhuma venda encontrada para os critérios selecionados.
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map((s) => (
                      <tr
                        key={s.id}
                        className="hover:bg-slate-900 transition-colors group cursor-pointer"
                        onDoubleClick={() => handlePrintHistoryOrder(s)}
                      >
                        {/* 1. NÚMERO */}
                        <td className="py-3.5 px-4 font-mono font-bold text-blue-400 whitespace-nowrap">
                          {s.numero}
                        </td>

                        {/* 2. CLIENTE / UNIDADE */}
                        <td className="py-3.5 px-4">
                          <div className="flex flex-col">
                            <span className="font-bold text-white text-xs leading-snug group-hover:text-blue-300 transition-colors">
                              {s.cliente}
                            </span>
                            <span className="text-[10px] text-slate-400 font-medium mt-0.5">
                              {s.unidade || "Matriz"}
                            </span>
                          </div>
                        </td>

                        {/* 3. SITUAÇÃO */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <span className="inline-flex items-center px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                            {s.situacao}
                          </span>
                        </td>

                        {/* 4. ITENS */}
                        <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-300">
                          {s.itensCount}
                        </td>

                        {/* 5. VALOR */}
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-white whitespace-nowrap">
                          R$ {s.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                        </td>

                        {/* 6. DATA */}
                        <td className="py-3.5 px-4 text-center font-mono text-slate-400 whitespace-nowrap">
                          {s.data}
                        </td>

                        {/* 7. AÇÕES (Editar e Imprimir Pedido A4) */}
                        <td className="py-3.5 px-4 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                alert(`Abrindo edição dos itens da venda ${s.numero}`);
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                              title="Editar Dados / Itens"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handlePrintHistoryOrder(s);
                              }}
                              className="p-1.5 rounded-lg bg-blue-950/80 border border-blue-800/80 hover:bg-blue-600 text-blue-300 hover:text-white transition"
                              title="Imprimir Pedido de Venda (Padrão A4 Oficial)"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* ABA 1: NOVA VENDA (PDV BALCÃO F1-F12)                           */}
      {/* ============================================================== */}
      {activeSubTab === "nova_venda" && (
        <div className="bg-slate-950 rounded-2xl p-6 text-white border border-slate-800 shadow-2xl flex flex-col gap-6 font-sans">
          {/* Top da Nova Venda */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-600 text-white shadow-md">
                <ShoppingCart className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black tracking-tight text-white flex items-center gap-2">
                  PDV Balcão ProAR — Frente de Caixa
                </h3>
                <div className="text-xs text-slate-400 flex items-center gap-4 mt-0.5">
                  <span>Cliente (F1): <strong className="text-white">{cliente}</strong></span>
                  <span>Operador: <strong className="text-white">{vendedor}</strong></span>
                </div>
              </div>
            </div>

            <div className="bg-blue-950/80 border border-blue-800/60 px-5 py-2.5 rounded-xl text-right">
              <span className="text-[10px] font-bold tracking-wider text-blue-300 uppercase block">Total a Pagar</span>
              <span className="text-2xl sm:text-3xl font-black text-emerald-400">
                R$ {totalVenda.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Barra de Atalhos F1–F12 */}
            <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800 space-y-1.5 text-[11px] font-mono font-semibold text-slate-400">
              <div className="text-[10px] uppercase font-bold text-slate-500 mb-2 px-2">Atalhos de Balcão</div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 flex justify-between"><span>[F1]</span> <span className="text-slate-300">Cliente</span></div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 flex justify-between"><span>[F2]</span> <span className="text-slate-300">Menu</span></div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 flex justify-between"><span>[F4]</span> <span className="text-slate-300">Pagamento</span></div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 flex justify-between"><span>[F6]</span> <span className="text-slate-300">Pesquisar</span></div>
              <div className="p-2 rounded bg-blue-900/40 border border-blue-700 text-blue-300 flex justify-between"><span>[F7]</span> <span>Finalizar</span></div>
              <div className="p-2 rounded bg-rose-950/40 border border-rose-800 text-rose-300 flex justify-between"><span>[F8]</span> <span>Excluir Item</span></div>
              <div className="p-2 rounded bg-rose-950/40 border border-rose-800 text-rose-300 flex justify-between"><span>[F9]</span> <span>Cancelar</span></div>
            </div>

            {/* Cupom no Centro */}
            <div className="lg:col-span-3 flex flex-col justify-between space-y-4">
              <form onSubmit={handleAddItem} className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputCode}
                    onChange={(e) => setInputCode(e.target.value)}
                    placeholder="Digite o código de barras, código do item ou 5*CODIGO e pressione Enter..."
                    className="w-full bg-slate-900 text-white placeholder-slate-500 pl-11 pr-4 py-2.5 rounded-xl border border-slate-700 focus:border-blue-500 outline-none font-mono text-sm font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition shadow"
                >
                  Lançar
                </button>
              </form>

              <div className="bg-slate-900/90 rounded-xl border border-slate-800 overflow-hidden divide-y divide-slate-800/80 min-h-[260px] max-h-[380px] overflow-y-auto">
                {items.length === 0 ? (
                  <div className="p-12 text-center text-slate-500 text-xs">Nenhum item no cupom atual. Digite um código acima.</div>
                ) : (
                  items.map((item) => {
                    const isSelected = selectedItemId === item.id;
                    return (
                      <div
                        key={item.id}
                        onClick={() => setSelectedItemId(item.id)}
                        className={`p-3.5 flex items-center justify-between gap-4 transition cursor-pointer ${
                          isSelected
                            ? "bg-blue-950/80 border-l-4 border-l-blue-500 text-white"
                            : "bg-slate-900/40 hover:bg-slate-900 text-slate-300"
                        } ${item.isRecent ? "ring-2 ring-blue-400 bg-blue-900/60" : ""}`}
                      >
                        <div className="space-y-0.5 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-bold">
                              {item.codigo}
                            </span>
                            <span className="text-[10px] font-bold text-blue-400 uppercase">{item.tipo}</span>
                          </div>
                          <div className="text-xs font-bold text-white">{item.descricao}</div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            R$ {item.valorUnitario.toFixed(2)} un
                          </div>
                        </div>

                        <div className="flex items-center gap-4 shrink-0">
                          <div className="flex items-center border border-slate-700 bg-slate-900 rounded-lg overflow-hidden">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleUpdateQuantity(item.id, -1);
                              }}
                              className="px-2 py-1 text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2.5 py-1 text-xs font-mono font-bold text-white">
                              {item.quantidade}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleUpdateQuantity(item.id, 1);
                              }}
                              className="px-2 py-1 text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-right w-24">
                            <span className="text-sm font-black text-emerald-400 font-mono">
                              R$ {item.valorTotal.toFixed(2)}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveItem(item.id);
                            }}
                            className="text-slate-500 hover:text-rose-400 p-1 rounded transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-400">
                  Total de itens: <strong>{items.length}</strong>
                </span>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setPrintDocumentData({
                        tipo: "PEDIDO",
                        numero: `PED-${Date.now().toString().slice(-6)}`,
                        data: new Date().toLocaleDateString("pt-BR"),
                        cliente: { nome: cliente, endereco: "Venda Presencial Balcão - Mirassol/SP" },
                        descricaoServico: "Venda e fornecimento de materiais e serviços técnicos de balcão.",
                        itens: items.map((it, idx) => ({
                          itemNum: String(idx + 1).padStart(2, "0"),
                          equipamentoOuItem: it.descricao,
                          capacidadeOuDetalhes: it.tipo,
                          quantidade: it.quantidade,
                          valorUnitario: it.valorUnitario,
                          valorTotal: it.valorTotal,
                        })),
                        valorGlobal: totalVenda,
                        onClose: () => setPrintDocumentData(null),
                      });
                    }}
                    className="px-4 py-2 bg-blue-700 hover:bg-blue-600 text-xs font-bold text-white rounded-xl transition flex items-center gap-1.5 shadow"
                  >
                    <Printer className="w-3.5 h-3.5" /> Imprimir Pedido A4
                  </button>
                  <button
                    type="button"
                    onClick={() => setItems([])}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 rounded-xl transition"
                  >
                    Limpar [F9]
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPaymentModal(true)}
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-xs font-black text-white rounded-xl shadow-lg transition flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" /> Finalizar Venda [F7]
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Modal de Pagamento & Troco */}
          {showPaymentModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
              <div className="bg-slate-900 border border-slate-700 max-w-md w-full rounded-2xl p-6 shadow-2xl text-white space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <h3 className="text-base font-bold flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-blue-400" /> Formas de Pagamento
                  </h3>
                  <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-white">
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="text-center py-2 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total do Cupom</span>
                  <span className="text-2xl font-black text-emerald-400">
                    R$ {totalVenda.toFixed(2)}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">PIX Instantâneo (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={valorPix || ""}
                      onChange={(e) => setValorPix(parseFloat(e.target.value) || 0)}
                      placeholder="0,00"
                      className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700 outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Dinheiro em Espécie (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={valorDinheiro || ""}
                      onChange={(e) => setValorDinheiro(parseFloat(e.target.value) || 0)}
                      placeholder="0,00"
                      className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700 outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Cartão Débito/Crédito (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={valorCartao || ""}
                      onChange={(e) => setValorCartao(parseFloat(e.target.value) || 0)}
                      placeholder="0,00"
                      className="w-full bg-slate-950 text-white p-2 rounded-lg border border-slate-700 outline-none focus:border-blue-500 font-mono"
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Total Informado:</span>
                    <span className="font-mono font-bold text-white">R$ {totalPago.toFixed(2)}</span>
                  </div>
                  {faltaPagar > 0 ? (
                    <div className="flex justify-between text-rose-400 font-bold">
                      <span>Falta Pagar:</span>
                      <span className="font-mono">R$ {faltaPagar.toFixed(2)}</span>
                    </div>
                  ) : (
                    <div className="flex justify-between text-emerald-400 font-bold">
                      <span>Troco:</span>
                      <span className="font-mono">R$ {troco.toFixed(2)}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowPaymentModal(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-medium rounded-lg"
                  >
                    Voltar
                  </button>
                  <button
                    type="button"
                    disabled={faltaPagar > 0 || items.length === 0}
                    onClick={() => {
                      const newSale: SaleRecord = {
                        id: Date.now().toString(),
                        numero: `VEN-${Math.floor(100000 + Math.random() * 900000)}`,
                        cliente: cliente,
                        unidade: "Matriz",
                        situacao: "Pedido confirmado",
                        itensCount: items.length,
                        valor: totalVenda,
                        data: new Date().toLocaleDateString("pt-BR"),
                        itens: items.map((it, idx) => ({
                          itemNum: String(idx + 1).padStart(2, "0"),
                          equipamentoOuItem: it.descricao,
                          capacidadeOuDetalhes: it.tipo,
                          quantidade: it.quantidade,
                          valorUnitario: it.valorUnitario,
                          valorTotal: it.valorTotal,
                        })),
                      };

                      setSalesHistory([newSale, ...salesHistory]);
                      alert("✓ Venda finalizada com sucesso! Gravada no Histórico de Vendas.");
                      setItems([]);
                      setShowPaymentModal(false);
                      setValorPix(0);
                      setValorDinheiro(0);
                      setValorCartao(0);
                      setActiveSubTab("historico");
                    }}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-xs font-black rounded-lg transition"
                  >
                    Confirmar Pagamento
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* ABA 3: CAIXA                                                    */}
      {/* ============================================================== */}
      {activeSubTab === "caixa" && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 space-y-6 text-white">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-white">Controle de Caixa Balcão</h3>
              <p className="text-xs text-slate-400">Movimentação diária, recebimentos em PIX, espécie e sangrias.</p>
            </div>
            <div className="px-3 py-1 bg-emerald-950 border border-emerald-800 text-emerald-400 rounded-lg text-xs font-bold">
              Status: Aberto às 07:30
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-bold text-slate-400 uppercase">Abertura</span>
              <div className="text-xl font-black text-white mt-1">R$ 200,00</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-bold text-slate-400 uppercase">Recebido em PIX</span>
              <div className="text-xl font-black text-blue-400 mt-1">R$ 1.513,40</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-bold text-slate-400 uppercase">Recebido em Dinheiro</span>
              <div className="text-xl font-black text-emerald-400 mt-1">R$ 17,25</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-bold text-slate-400 uppercase">Saldo em Caixa</span>
              <div className="text-xl font-black text-emerald-400 mt-1">R$ 1.730,65</div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL PADRONIZADO A4 DE IMPRESSÃO (SEM FOLHA EM BRANCO)         */}
      {/* ============================================================== */}
      {printDocumentData && (
        <StandardDocumentReport
          tipo={printDocumentData.tipo}
          numero={printDocumentData.numero}
          data={printDocumentData.data}
          cliente={printDocumentData.cliente}
          descricaoServico={printDocumentData.descricaoServico}
          itens={printDocumentData.itens}
          valorGlobal={printDocumentData.valorGlobal}
          condicoesComerciais={printDocumentData.condicoesComerciais}
          onClose={() => setPrintDocumentData(null)}
        />
      )}
    </div>
  );
}
